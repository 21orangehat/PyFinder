import tempfile
import multiprocessing
from subprocess import call
from datetime import datetime


CONTADOR: int = 1
TIMEOUT: int = 1800 # 30 minutos
THREADS: int = multiprocessing.cpu_count()

PUZZLE_ID: int = 67
CARTEIRA: str = "1BY8GQbnueYofwSuFAT3USAhGjPrkxDdW9"

"""
[
    '40000000000000000:4fffffffffffffffe', 
    '4ffffffffffffffff:5fffffffffffffffd', 
    '5fffffffffffffffe:6fffffffffffffffc', 
    '6fffffffffffffffd:7ffffffffffffffff'
]
"""


def job(range_str: str):
    global CONTADOR
    
    # Cria o arquivo temporário com o nome do puzzle Ex: '/tmp/67_jpyjf5y3.txt'
    fp = tempfile.NamedTemporaryFile(prefix=f"{PUZZLE_ID}_p1_",suffix=".txt")

    # Escreve o endereço (em formato binário) da carteira no arquivo temporário
    fp.write(f"{CARTEIRA}".encode('utf-8'))
    fp.flush()

    start_time = datetime.now()
    print('-----------------------------')
    print(f"=========[67 P1 - {CONTADOR}]=========")
    print(f"Início da Execução: {start_time}")
    print(f'Puzzle Id: {PUZZLE_ID}')
    print(f'Carteira: {CARTEIRA}')
    print(f'Range de busca: {range_str} ')
    print('-----------------------------')

    try:
        retcode = call(['./keyhunt', '-m', 'address', '-f', f'{fp.name}', '-r', f':{range_str}', '-l', 'compress', '-t', f'{THREADS}', '-e', '', '-R', '', '-n', '102400000000',  '-q', ''])
    except Exception as err:
        retcode = -1
        fim_time = datetime.now()
        print(f'Fim da Execução: {fim_time} {err}')
    finally:
        print("================================")
        CONTADOR = CONTADOR + 1
    
if __name__ == "__main__":
    job(range_str='40000000000000000:4fffffffffffffffe')
