import tempfile
import schedule
import multiprocessing
from subprocess import call
from random import sample
from random import SystemRandom
from datetime import datetime


CONTADOR: int = 1
TIMEOUT: int = 3600 # 1 hora(s)
HOUR: int = int((TIMEOUT / 60) / 60)
THREADS: int = multiprocessing.cpu_count()

PUZZLE_ID: int = 67
CARTEIRA: str = "1BY8GQbnueYofwSuFAT3USAhGjPrkxDdW9"


def load_range():
    with open('puzzles/67r1.txt', 'r') as file:
        ranges = file.readlines()
    
    # ['65c28f5c28f5c28d0:6666666666666663f\n']
    escolha = sample(ranges, 1)
    
    return escolha



def job():
    global CONTADOR
    
    # ['65c28f5c28f5c28d0:6666666666666663f\n']
    range_puzzle = load_range()

    # Retira o \n e separa os elementos em lista
    # ['78f5c28f5c28f5c10', '7999999999999997f']
    range_puzzle = range_puzzle[0].split()[0].split(':')

    # Crie um objeto rgen
    rgen = SystemRandom()
    """
    # Passo 1
    - Gera um primeiro valor aleatório entre o início e o fim.
    Este valor, claro, será maior que o início e menor que o fim.

    # Passo 2
    - Então geramos um segundo valor aleatório entre o início e o fim.
    Este valor, também será maior que o início e menor que o fim.

    # Passo 3
    - Precisamos agora ordenar para que o menor seja o início e o maior o fim.
    """
    # Passo 1
    ibusca_int: int = rgen.randint(int(range_puzzle[0], 16), int(range_puzzle[1], 16))
    # Passo 2
    jbusca_int: int = rgen.randint(int(range_puzzle[0], 16), int(range_puzzle[1], 16))
    # Passo 3
    if ibusca_int < jbusca_int:
        inicio = ibusca_int
        fim = jbusca_int
    else:
        inicio = jbusca_int
        fim = ibusca_int

    # Converter o valor para hex
    ibusca_hex: str = hex(inicio)[2:]
    jbusca_hex: str = hex(fim)[2:]
    
    # Cria o arquivo temporário com o nome do puzzle Ex: '/tmp/67_jpyjf5y3.txt'
    fp = tempfile.NamedTemporaryFile(prefix=f"{PUZZLE_ID}_",suffix=".txt")

    # Escreve o endereço (em formato binário) da carteira no arquivo temporário
    fp.write(f"{CARTEIRA}".encode('utf-8'))
    fp.flush()

    start_time = datetime.now()
    print('-----------------------------')
    print(f"=========[67 P1 - {CONTADOR}]=========")
    print(f"Início da Execução: {start_time}")
    print(f'Puzzle Id: {PUZZLE_ID}')
    print(f'Carteira: {CARTEIRA}')
    print(f'Range de busca [Original]: {range_puzzle[0]}:{range_puzzle[1]}')
    print(f'Range de busca [Random]: {ibusca_hex}:{jbusca_hex}')
    print('-----------------------------')

    try:
        # Executa durante 1 hora...
        # ./keyhunt -m address -f /puzzles/r67.txt -r:0x52f8f8043e03cd5a2:0x5333333333333331f -l compress -s 10 -t 16 -e -n 1024
        # ./keyhunt -m bsgs -f tests/125.txt -b 125 -q -s 10 -R -k 21 -S -t 4
        retcode = call(['./keyhunt', '-m', 'address', '-f', f'{fp.name}', '-r', f':{ibusca_hex}:{jbusca_hex}', '-l', 'compress', '-t', f'{THREADS}', '-e', '', '-R', '', '-n', '102400',  '-q', ''], timeout=TIMEOUT)
    except Exception as err:
        retcode = -1
        fim_time = datetime.now()
        print(f'Fim da Execução: {fim_time} {err}')
    finally:
        print("================================")
        CONTADOR = CONTADOR + 1
    
        # Se o programa encontrar uma chave e sair, inicia novamente
        if retcode == 0:
            job()


if __name__ == "__main__":
    schedule.every(HOUR).hours.do(job)

    while True:
        schedule.run_all(delay_seconds=10)
